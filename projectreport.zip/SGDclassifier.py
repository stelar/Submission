from sklearn.linear_model import SGDClassifier
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import os
from sklearn import metrics
from sklearn.model_selection import train_test_split
import glob
from sklearn import linear_model
import numpy as np
from scipy import misc
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import cv2
import matplotlib.pyplot as plt
classes = ['abstract', 'Checked','Colourblock', 'floral', 'graphic', 'Melange', 'Patterned', 'polka dots', 'Printed',           'solid', 'striped', 'typography']
validation_size = 0.2
image_size = 128
num_channels = 3
train_path = "train"


def read_train_sets(train_path):
    images = []
    labels = []
    img_names = []
    cls = []
    for fields in classes:
        tempImages = []
        index = classes.index(fields)
        print('Now going to read {} files (Index: {})'.format(fields, index))
        path = os.path.join(train_path, fields, '*g')
        files = glob.glob(path)
        for fl in files:
            image = cv2.imread(fl)
            image = cv2.resize(image, (image_size, image_size))
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            [width1, height1] = [image.shape[0], image.shape[1]]
            f2 = image.reshape(width1 * height1);
            images.append(f2)
            label = np.zeros(len(classes))
            label[index] = 1.0
            labels.append(label)
            flbase = os.path.basename(fl)
            img_names.append(flbase)
            cls.append(fields)

    print(len(images))
    return images, cls


# We shall load all the training and validation images and labels into memory using openCV and use that during training
import pandas as pd
data, labels = read_train_sets(train_path)

data=np.array(data)
labels=np.array(labels)
print(labels.shape)
train_data, test_data, train_labels, test_labels = train_test_split(data, labels,
                                                                    test_size=0.2, random_state=42)
size=len(train_labels)
train_data=np.array(train_data)
print(train_data.shape)
train_labels=np.array(train_labels)
print(train_labels.shape)
dataset = pd.DataFrame({'label': labels, 'data': list(data)}, columns=['label', 'data'])
print(dataset.shape)
datal=dataset['label']
datal.hist()
plt.show()
est = SGDClassifier(penalty="l2", alpha=0.001, shuffle=True)
for datapoint in range(1, size, 200):

    if datapoint <= size:
        print(datapoint)
        X_batch = train_data[datapoint:datapoint + 200]
        print(X_batch.shape)
        y_batch = train_labels[datapoint:datapoint + 200]
        est.partial_fit(X_batch, y_batch, classes=np.unique(y_batch))

pred = est.predict(test_data)
print(metrics.accuracy_score(test_labels, pred))